export class RegisterResponseDto {
  id: number;
  username: string;
  roles: string[];
}
