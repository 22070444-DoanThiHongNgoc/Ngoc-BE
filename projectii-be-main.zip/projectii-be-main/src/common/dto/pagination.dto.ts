export class PaginationDto {}
